class InternalState { 
    void save() ;
    void read() ;
};

// DLL
class PersonalInfoScreen : UserControl {
    // instance Data Members
    void show() {
    }
    void hide() {
    }
    class PersonalInfoDate : public InternalState {
        void save(fileobject) {
            
        }
        read(fileobject) {
        }
    };
    unique_ptr<InternalState> getData() {
        return :: ;
    }
} pi;

// DLL
class FinancialInfoScreen : UserControl { 
    // instance Data Members
    void show() {
    }
    void hide() {
    }
    unique_ptr<InternalState> getData() {
        return :: ;
    }
} fi;

// DLL
class EducationalQualificationInfoScreen : UserControl { 
    // instance Data Members
    void show() {
    }
    void hide() {
    }
    unique_ptr<InternalState> getData() {
        return :: ;
    }
} eqi ;

class Wizard {
     
    
    int index = 0 ;
    
    Wizard() { 
        // load DLLs by the order mentioned file
    }
    
    next() {
        screens[index - 1]->hide() ; 
        screens[index]->show() ; 
        index++;
    }
    
    back() {
        screens[index]->hide() ; 
        screens[index-1]->show() ; 
        index--;
    }
};