#include <iostream>
#include <vector>
#include <algorithm>
#include <list>
#include <mutex>
#include <memory>
#include <iterator>
using namespace std;

/*
I VTable
&I::Dtor
*/
class I {
    // vptr ;
public:
    virtual ~I() { } 
} ;

/*
I1 VTable
&I1::f1
&I1::f2
*/
class I1 : virtual public I {
public:
    // I1 ( this ) { this->vptr = &I1_Vtable ; } 
    virtual void f1() = 0 ; // offset : 0
    virtual void f2() = 0 ; // offset : 8 
};

/* I2 VTable
&I2::F3
&I2::F4
*/
class I2 : virtual public I {
public:
    // ctor ::::
    virtual void f3() = 0 ; // offset : 0
    virtual void f4() = 0 ; // offset : 8 
} ;

/* A1 Vtable - I1
&A1::f1
&A1::f2
*/
/* A1 Vtable - I2
&A1::f3
&A1::f4
*/
class A1 : public I1, public I2 {
    
    // ctor() { I1vptr = &A1Vtable-I1 ; I2vptr = &A1Vtable-I2 } 
    
    void f2() {
         cout << "A1 - f2" << endl ;
    }
    
    void f1() {
        cout << "A1 - f1" << endl ;
    }
    
     void f4() {
         cout << "A1 - f4" << endl ;
    }
    
    void f3() {
        cout << "A1 - f3" << endl ;
    }
};

void work ( I *v ) { // 1000
    
    I1 *i1 = dynamic_cast<I1*> ( v ); // 1000
    if ( i1 != nullptr ) {
        i1->f1() ;
        i1->f2() ;
    }
    
    I2 *i2 = dynamic_cast<I2*> ( v ); // 1000
    if ( i2 != nullptr ) {
        i2->f3() ;
        i2->f4() ;
    }
    
}

int main() {
    
    A1 a1 ; // address of the object - 1000 // 1000 - I1vptr and 1004 - I2vptr
    work ( &a1 ) ; // 1000
    
    return 0 ;
}

// class Abstraction {
// public:
//     // define which can be throw implementation classes
//     virtual void work() noexcept = 0 ;
// } ;

// class Implementation1 { 
//     Abstraction *abstraction;
// public:
//     Implementation1 ( Abstraction *abstraction ) : abstraction(abstraction) {
//     }
    
//     void f1() {
//         abstraction->work();
//     }
// } ;

// class VaryingImplementationA1 : public Abstraction {
//     void work() {
//         cout << "VaryingImplementationA1 work" << endl ;
//     }
// };

// class VaryingImplementationA2 : public Abstraction {
//     void work() {
//         cout << "VaryingImplementationA1 work" << endl ;
//         throw "something here" ; 
//     }
// };


// int main() {
//     VaryingImplementationA1 va1 ; 
//     Implementation1 i1 ( &va1 ) ;
//     i1.f1();
// }