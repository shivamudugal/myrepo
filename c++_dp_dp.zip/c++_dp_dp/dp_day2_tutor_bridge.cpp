#include <iostream>
#include <memory>
#include <vector>
#include <string>
using namespace std ; 

class GraphicsLibrary {
public:
    virtual void drawRectangle() = 0 ; 
    virtual ~GraphicsLibrary() { } // virtual dtor
} ; 

class DirectXAdapter : public GraphicsLibrary {
    void drawRectangle() { 
        cout << "DirectX Rectangle" ;
    }
} ;

class OpenGLAdapter : public GraphicsLibrary {
    void drawRectangle() { 
        cout << "OpenGL Rectangle" ;
    }
} ;

// simple factory
unique_ptr<GraphicsLibrary> GetGraphicsLibrary() { 
    return unique_ptr<GraphicsLibrary> ( new DirectXAdapter() ) ;
}

// ----------------------------------------------

class UIControl { 
protected:

    unique_ptr<GraphicsLibrary> gl ; 

    UIControl() { 
        gl = GetGraphicsLibrary() ; 
    }
    
public:

    virtual void draw() = 0 ;
    
    virtual ~UIControl() { } // virtual dtor is must when abstraction pointers 
    // hold address dynamically created implementation objects
};

class Button : public UIControl {
    void draw() {
        cout << "Button: " ;
        gl->drawRectangle() ;
        cout << endl ; 
    }
};

class ListBox : public UIControl { 
    void draw() {
        cout << "ListBox: " ;
        gl->drawRectangle() ;
        cout << endl ;  
    }
};

int main() {
    
    vector<unique_ptr<UIControl>> uicontrols ; 
    uicontrols.emplace_back ( new Button() ) ;
    uicontrols.emplace_back ( new ListBox() ) ;
    uicontrols.emplace_back ( new Button() ) ;
    uicontrols.emplace_back ( new ListBox() ) ;
    uicontrols.emplace_back ( new Button() ) ;
    
    for ( unique_ptr<UIControl>& uicontrol : uicontrols ) {
        uicontrol->draw() ;
    }
    
    
    
    return 0 ;
}
