// Example program
#include <iostream>
#include <string>
#include <vector>
#include <algorithm>>
using namespace std ; 

class NavyData {
private:
    NavyData() { 
    }
    static unique_ptr<NavyData> navyData ; 
    mutex m ;
public:
    static unique_ptr<NavyData> get() {
        if ( navyData == nullptr ) {
            lock_guard<mutex> guard(m); // m.lock()
            if ( navyData == nullptr ) 
                navyData = unique_ptr<NavyData> ( new NavyData() ) ;
        }
        return navyData ; 
    }
    static unique_ptr<NavyData> createNew() {
        return unique_ptr<NavyData> ( new NayData() ) ;
    }
} ;
unique_ptr<NavyData> NavyData::navyData = nullptr ;

int main()
{
    unique_ptr<NavyData>& p1 = NavyData::get();
    unique_ptr<NavyData>& p2 = NavyData::get();
    
  vector<int> tabs = { 10, 20, 30, 40, 50, 60, 70, 80 } ;
  rotate ( begin(tabs) + 2, begin(tabs) + 4, begin(tabs) + 7 ) ;
  for ( int item : tabs ) 
    cout << item << " " ;
    
    return 0 ;
}