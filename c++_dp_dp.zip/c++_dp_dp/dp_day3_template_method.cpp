class Grid : public UserControl {
protected:

    virtual void beforeAddColumn() { } 
    virtual void afterAddColumn() { } 

    addColumn( ::: ) { 
        beforeAddColumn() ;
        // Common Code - Data
        afterAddColumn() ; 
    }
    
    deleteColumn ( ::: ) { 
         // Common Code
    }
    
    addRow ( ) { 
         // Common Code
    }
    
    deleteRow() {
         // Common Code
    }
    
    :::
}

class PrescriptionGrid : public Grid {
    
public:
    beforeAddColumn( ::: ) { 
    }
    
}

class ComplicationGrid : public Grid { 
public:

    afterAddColumn( ::: ) { 
    }
    
  
}