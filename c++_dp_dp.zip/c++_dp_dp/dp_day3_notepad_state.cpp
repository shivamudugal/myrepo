class State { 
    virtual void onClose() = 0 ; 
};

class NewFileState : public State {
    Notepad *notepad ; 
    NewFileState(Notepad *notepad) : notepad(notepad) {
    }
     void onClose() {
        // if there is new text typed
            // show prompt: Save, Dont Save, Cancel
                // if Cancel
                    // close the prompt
                // if Dont Save
                    // close the prompt and notepad window
                // if Save
                    // show save file dialog: Save and Cancel
                        // Is Save
                            // Change To ExistingFileState
                            notepad->changeToExistingFileState() ; 
     }
};

class ExistingFileState : public State {
    void onClose() {
        // if there is new text typed
    }
};

class Notepad : public CFrameWnd {
    
    NewFileState nfs ;
    ExistingFileState efs ;
    
    State *currentState ; 
    
public:

    Notepad(/* this = &notepad object */) : nfs(this) {
        // Create Close Button : Attached Event Handler
        this->currentState = &nfs ; 
    }
    
    void changeToExistingFileState(/* this = &notepad object */) {
        this->currentState = &efs ;
    }
    
    void changeToNewFileState(/* this = &notepad object */) {
        this->currentState = &nfs ;
    }
    
    void onClose(/* this = &notepad object */) {
        this->currentState->onClose();
    }
} ;

int main() {
    Notepad notepad ; 
    notepad.show();
}