// Example program
#include <iostream>
#include <string>

// // Developer - 1: We have to implement functionality of Stack
// // Version - 1
// // This Design is Single Instance Design

// // int items[10] ; // global is good to get created only once
// // int top = 0 ; 

// // void push(int item) {
// //     items[top] = item ; 
// //     top++;
// // }

// // int pop() {
// //     top-- ;
// //     return items[top] ; 
// // }

// // -------------------------------------------------

// // Version - 2
// // Multi-Instance Design
// // For Multiple Instances a Data Type is required.
// struct Stack // New Data Type (no memory is allocated)
// {
//     int items[10] ; // data member
//     int top = 0 ; // data member
// } ;

// // functionality has to work on instance (object) of the data type
// void push ( Stack * const s, int item ) 
// {
//     s->items[s->top] = item ; 
//     s->top++;
// }

// int pop ( Stack * const s, int item ) 
// {
//     s->top-- ;
//     return s->items[s->top] ; 
// }

// // --------------------------------------------------

// // Version - 3 - C++ : Multi-Instance Design - Data Type

// // Implementation - Data Types
// // contains instance data members or instance methods to perform specific work
// // we create object of such data type
// struct Stack // New Data Type - Implementation
// {
//     // instance data members - become part of every instance
//     int items[10];
//     int top = 0; 
    
//     // instance methods - loaded only once in the memory
//     void push ( int item ) // void push ( Stack * const this, int item )
//     {
//         items[top] = item ; // this->items[this->top] = item  ;
//         top++ ; // this->top++;
//     }
    
//     int pop() // int pop ( Stack * const this )
//     {
//         top-- ; // this->top--;
//         return items[top] ;   // this->items[this->top] ;
//     }
// };

// // --------------------------------------------------

// // Developer - 2
// int main()
// {
//     Stack s1, s2 ; // more than 2 instances can be created
//     // multiple objects
//     // each object can contain data members in memory to hold data
//     // for each object instance methods perform the work using the object's data
    
//     s1.push ( 1000 ) ; // push ( &s1, 1000 ) ;
//     s1.push ( 2000 ) ; // push ( &s1, 2000 ) ;
    
//     s2.push ( 100 ) ; // push ( &s2, 100 ) ;
//     s2.push ( 200 ) ; // push ( &s2, 200 ) ;
    
//     printf ( "%d\n", s2.pop() /* pop ( &s2 ) */ ) ; // 200
//     printf ( "%d\n", s1.pop() /* pop ( &s1 ) */ ) ; // 2000
    
//     return 0 ;
    
// }

// Requirement - 2

#include <iostream>
#include <string>
#include <vector>
using namespace std ; 

// Encapsulation: Hiding VARYING Implementations behind Abstraction - OCP

// Will be used by the Client 
// This type is used to hide Implementation Type Names from Client
class Command // Abstract Type (Base Type of VARYING Implementation Types)
{
public:

    static vector<Command*> commands  ; // it will not become part of any object
    
    // this helps in telling that we need late-bound call so that compiler can generate
    // proper instructions where we have made a call
    virtual void perform ( const string& commandName, double commandValue, double& value ) = 0 ; // pure-virtual
    
protected:

    Command ( /* Command * const this = &addCommand and &mulCommand */ ) 
    {
        commands.push_back ( this ) ; 
    }
    
} ;

vector<Command*> Command::commands ; // irritating syntax

// Client 
int main() 
{
    string commandName ; // for taking input from the user
    double commandValue ;  // for taking input from the user
    
    double value = 0 ; 
    
    while ( true )
    {
        cout << value << endl ; // 0
        
        cin >> commandName >> commandValue ;  // add 10 or mul 3
        
        // to invoke perform method we need objects of AddCommand and MulCommand
        for ( Command *command : Command::commands )  // iteration
        {
            command->perform ( commandName, commandValue, value ) ; // Late-Bound Call
        }
        
    }
    
    return 0 ; 
}

// -------------------------------------

// Implementation Data Type - Object of it should perform specific work - add
struct AddCommand : public Command // SRP 
{
    // AddCommand ( AddCommand * const this = &addCommand ) : Command ( value of this ) { } 
    
    // instance method
    void perform ( const string& commandName, double commandValue, double& value ) 
    {
        if ( commandName ==  "add" ) 
            value = commandValue + value ; 
    }
    
} addCommand ; // global object
// Object Creation is a 2-step process:
// 1. Memory is allocated for the object
// 2. Ctor ( &address of the object )


// Implementation Data Type - Object of it should perform specific work - mul
class MulCommand : public Command // SRP
{
    // MulCommand ( MulCommand * const this = &mulCommand ) : Command ( value of this ) { } 
        
    // instance method
    void perform ( const string& commandName,  double commandValue, double& value ) 
    {
        if ( commandName == "mul" ) 
            value = commandValue * value ; 
    }
    
} mulCommand ; // global object
// 1. Memory is allocated for the object
// 2. Ctor ( &address of the object )
 ————————————



// // Example program
// #include <iostream>
// #include <string>

// // // Developer - 1: We have to implement functionality of Stack
// // // Version - 1
// // // This Design is Single Instance Design

// // // int items[10] ; // global is good to get created only once
// // // int top = 0 ; 

// // // void push(int item) {
// // //     items[top] = item ; 
// // //     top++;
// // // }

// // // int pop() {
// // //     top-- ;
// // //     return items[top] ; 
// // // }

// // // -------------------------------------------------

// // // Version - 2
// // // Multi-Instance Design
// // // For Multiple Instances a Data Type is required.
// // struct Stack // New Data Type (no memory is allocated)
// // {
// //     int items[10] ; // data member
// //     int top = 0 ; // data member
// // } ;

// // // functionality has to work on instance (object) of the data type
// // void push ( Stack * const s, int item ) 
// // {
// //     s->items[s->top] = item ; 
// //     s->top++;
// // }

// // int pop ( Stack * const s, int item ) 
// // {
// //     s->top-- ;
// //     return s->items[s->top] ; 
// // }

// // // --------------------------------------------------

// // // Version - 3 - C++ : Multi-Instance Design - Data Type

// // // Implementation - Data Types
// // // contains instance data members or instance methods to perform specific work
// // // we create object of such data type
// // struct Stack // New Data Type - Implementation
// // {
// //     // instance data members - become part of every instance
// //     int items[10];
// //     int top = 0; 
    
// //     // instance methods - loaded only once in the memory
// //     void push ( int item ) // void push ( Stack * const this, int item )
// //     {
// //         items[top] = item ; // this->items[this->top] = item  ;
// //         top++ ; // this->top++;
// //     }
    
// //     int pop() // int pop ( Stack * const this )
// //     {
// //         top-- ; // this->top--;
// //         return items[top] ;   // this->items[this->top] ;
// //     }
// // };

// // // --------------------------------------------------

// // // Developer - 2
// // int main()
// // {
// //     Stack s1, s2 ; // more than 2 instances can be created
// //     // multiple objects
// //     // each object can contain data members in memory to hold data
// //     // for each object instance methods perform the work using the object's data
    
// //     s1.push ( 1000 ) ; // push ( &s1, 1000 ) ;
// //     s1.push ( 2000 ) ; // push ( &s1, 2000 ) ;
    
// //     s2.push ( 100 ) ; // push ( &s2, 100 ) ;
// //     s2.push ( 200 ) ; // push ( &s2, 200 ) ;
    
// //     printf ( "%d\n", s2.pop() /* pop ( &s2 ) */ ) ; // 200
// //     printf ( "%d\n", s1.pop() /* pop ( &s1 ) */ ) ; // 2000
    
// //     return 0 ;
    
// // }

// // Requirement - 2

// #include <iostream>
// #include <string>
// #include <map>
// using namespace std ; 

// // Encapsulation: Hiding VARYING Implementations behind Abstraction - OCP

// // Will be used by the Client 
// // This type is used to hide Implementation Type Names from Client
// class Command // Abstract Type (Base Type of VARYING Implementation Types)
// {
// public:

//     static map<string,Command*> commands  ; // it will not become part of any object
    
//     // this helps in telling that we need late-bound call so that compiler can generate
//     // proper instructions where we have made a call
//     virtual void perform ( const string& commandName, double commandValue, double& value ) = 0 ; // pure-virtual
    
// protected:

//     Command ( /* Command * const this = &addCommand and &mulCommand */ const string& commandName ) 
//     {
//         // TODO: if there are conflicting commandName 
        
//         commands[commandName] = this ; 
//     }
    
// } ;

// map<string, Command*> Command::commands ; // irritating syntax

// // Client 
// int main() 
// {
//     string commandName ; // for taking input from the user
//     double commandValue ;  // for taking input from the user
    
//     double value = 0 ; 
    
//     while ( true )
//     {
//         cout << value << endl ; // 0
        
//         cin >> commandName >> commandValue ;  // add 10 or mul 3
        
//         // to invoke perform method we need objects of AddCommand and MulCommand
//         //for ( Command *command : Command::commands )  // iteration
//         {
//             Command::commands[commandName]->perform ( commandValue, value ) ; // Late-Bound Call
//         }
        
//     }
    
//     return 0 ; 
// }

// // -------------------------------------

// // Implementation Data Type - Object of it should perform specific work - add
// struct AddCommand : public Command // SRP 
// {
//     // AddCommand ( AddCommand * const this = &addCommand ) : Command ( value of this ) { } 
    
//     // instance method
//     void perform ( const string& commandName, double commandValue, double& value ) 
//     {
//         if ( commandName ==  "add" ) 
//             value = commandValue + value ; 
//     }
    
// } addCommand("add") ; // global object
// // Object Creation is a 2-step process:
// // 1. Memory is allocated for the object
// // 2. Ctor ( &address of the object )


// // Implementation Data Type - Object of it should perform specific work - mul
// class MulCommand : public Command // SRP
// {
//     // MulCommand ( MulCommand * const this = &mulCommand ) : Command ( value of this ) { } 
        
//     // instance method
//     void perform ( const string& commandName,  double commandValue, double& value ) 
//     {
//         if ( commandName == "mul" ) 
//             value = commandValue * value ; 
//     }
    
// } mulCommand("mul") ; // global object
// // 1. Memory is allocated for the object
// // 2. Ctor ( &address of the object )


// // Implementation Type
// class sdghshsgdhfghsgfsjdfjhsdjfhjsdhjfhdhsdfjdshgfjhsgdhfg : public Command 
// {
    
//     // ctor ( this ) : Command ( value of this ) { } 
    
//     void perform ( const string &commandName, double commandValue, double &value ) 
//     {
//         if ( commandName == "sub" )
//             value -= commandValue ; 
//     }
    
// } ajhdjhsdjhjhdjfjsdhfjshdjfjshdhdhsj ;




/// ——


#include <iostream>
#include <vector>
using namespace std ;

// Principles
// 1. OCP
// 2. SRP
// 3. DI - Dependency Inversion 

// DP
// 1. Factory Method

class Shape { 
    
public:
    virtual void input() = 0 ; 
    virtual void draw() = 0 ; 
    
};

class ShapeFactory { 
    
public:

    static vector<ShapeFactory*> factories ; 
    
    // to tell the compiler that we want late-bound call
    virtual string getShapeName() = 0 ; // pure-virtual
    virtual Shape* createShape() = 0 ; // pure-virtual
    
protected:

    ShapeFactory ( /* this */ ) {
        factories.push_back ( this ) ; 
    }
    
} ;

vector<ShapeFactory*> ShapeFactory::factories ; // definition


// client
int main() {
    
    vector<Shape*> shapes ; 
    int choice ; 
    
    while ( true ) {
        
        // Display shape names - Obtain Shape Names
        cout << "0: Redraw" << endl ; 
        int index = 1 ; 
        for ( ShapeFactory *factory : ShapeFactory::factories ) // iteration
        {
            cout << index << ": " << factory->getShapeName() << endl ;  // Late-Bound Call
            index++ ;
        }
        
        // Create the Object Shape Implementation Class.
        cout << "Select a Shape: " ;
        cin >> choice ; 
        
        if ( 0 == choice ) {
            
            for ( Shape *shape : shapes ) { 
                shape->draw() ; 
            }
            
            
        } else {
    
            // Delegate the work to it.
            Shape *shape = ShapeFactory::factories[choice-1]->createShape() ;  // Late-Bound Call
            
            shape->input() ; // Late-Bound call
            
            shape->draw() ; // Late-Bound call
            
            shapes.push_back ( shape ) ; 
            
        }
        
    }

    return 0 ; 
}

// ------------------------------------------------------------------

// Data Type
class Circle : public Shape {
    
    // instance data members
    int cx, cy, radius ; 
    
    // instance methods
    void input(/* this */) {
        cin >> cx >> cy >> radius ; 
    }
    
    void draw(/* this */) {
        cout << "Circle: " << cx << " " << cy << " " << radius << endl ;
    }
    
};

class CircleFactory : public ShapeFactory {
    
    // CircleFactory ( this ) : ShapeFactory ( value of this ) { } 
    
    string getShapeName() {
        return "Circle" ;
    }
    
    Shape*  createShape() {
        return new Circle() ; 
    }
    
} circleFactory ; // global 


// Data Type
class Rectangle : public Shape {
    
    // instance data members
    int left, top, width, height ; 
    
    // instance methods
    void input(/* this */) {
        cin >> left >> top >> width >> height ; 
    }
    
    void draw(/* this */) {
        cout << "Rectangle: " << left << " " << top << " " << height << "  " << width << endl ;
    }
    
};

class RectangleFactory : public ShapeFactory {
    
    // RectangleFactory ( this ) : ShapeFactory ( value of this ) { } 
    
    string getShapeName() {
        return "Rectangle" ;
    }
    
    Shape* createShape() {
        return new Rectangle() ; 
    }
    
} rectangleFactory ; // global





//.  -0—



// Example program
#include <iostream>
#include <functional>
using namespace std ; 

// void multiplicationTable ( int number, void (*callback) (int,int,int> ) {

void multiplicationTable ( int number, const function<void(int,int,int)>& callback ) {
    
    for ( int i = 1 ; i <= 10 ; i++ ) {
        
        int result = number * i ;
        
        callback ( number, i, result ) ;
    
    }
    
}

class Sample {
    
    int x ;

public:

    Sample ( int x ) : x ( x ) {
    }
    
    void receiver3 ( /* this */ int number, int i, int result ) { 
        cout << this->x << " : " << result << endl ; 
    }
    
    // receiver of the callback
    void operator() ( /* this */ int number, int i, int result ) { 
        cout << this->x << " : " << result << endl ; 
    }
    
    static void receiver4 ( int number, int i, int result ) { 
        cout << result << endl ; 
    }
    
} ; 

void receiver1 ( int number, int i, int result ) {
}

int main()
{
    Sample s1(90), s2(80) ; 
    
    multiplicationTable ( 6, receiver1 ) ; 
    
    multiplicationTable ( 7, bind ( &Sample::receiver3, &s1, placeholders::_1, placeholders::_2, placeholders::_3 ) ) ; 

    multiplicationTable ( 8, s2 ) ; 
    
    multiplicationTable ( 9, &Sample::receiver4 ) ; 
    
    multiplicationTable ( 10, [ ] (int number, int i, int result) { 
        
        cout << result << endl ;    
    
    } ) ; 
    
    
    
    
    
    
    return 0 ; 
}


















#include <iostream> // cin, cout, endl
#include <vector> // vector<> class
#include <string> // string class
#include <thread> // thread class
#include <mutex> // mutex<> class
#include <functional> // function<> class
#include <memory> // unique_ptr<>, shared_ptr<>, weak_ptr<>
using namespace std ; 

class Reminder { 
private:
    int day, month, year, hour, minute ; 
    string message ;
    
public:

    // making object non-copyable
    Reminder ( const Reminder& ) = delete ; 
    Reminder& operator= ( const Reminder& ) = delete ; 

    // getters
    int getDay ( /* Reminder const * const this */ ) const { return this->day ; } 
    int getMonth ( /* Reminder const * const this */ ) const { return this->month ; }
    int getYear ( /* Reminder const * const this */ ) const { return this->year ; }
    int getHour ( /* Reminder const * const this */ ) const { return this->hour ; }
    int getMinute ( /* Reminder const * const this */ ) const { return this->minute ; }
    const string& getMessage ( /* Reminder const * const this */ ) const { return this->message ; }
    
    Reminder(/* Reminder * const this */) {
    }
    
    Reminder (/* Reminder * const this */ int day, int month, int year, int hour, int minute, const string& message ) 
        : day(day), month(month), year(year), hour(hour), minute(minute), message(message) 
    { 
    }
}

// Rule 1: Break down the application into layers

// Data Access Layer - Can contain many classes


// Business Logic Layer - Can contain many classes

template<class T>
class Event {
private:

    vector<function<T>> listeners ; 
    mutex m ; // this is for synchronization of multiple threads working same object
    
public:

    Event ( const Event& ) = delete ; 
    Event& operator = ( const Event& ) = delete ; 
    
    Event() { }

    // this function might be called in different threads
    operator += (const function<T>& listener) {
        
        lock_guard<mutex> lg ( m ) ; 
        // when lg object is created it calls m.lock() in ctor

        listeners.push_back(listener);
  
    } // when lg object is about to die, its dtor is called and
    // inside the dtor it calls m.unlock() - irrespective of 
    // whether exception has occurred or not
    
    
    // this function might be called in different threads
    operator -= (const function<T>& listener) {
   
         lock_guard<mutex> lg ( m ) ; 
        // when lg object is created it calls m.lock() in ctor
        
        // TODO: remove the listener from the vector

    } // when lg object is about to die, its dtor is called and
    // inside the dtor it calls m.unlock() - irrespective of 
    // whether exception has occurred or not
    
    // this function might be called in secondary thread
    // variadic templates
    template<class TArgs...>
    void notify(TArgs&& args...) {
        
        {
            lock_guard<mutex> lg ( m ) ; 
            // when lg object is created it calls m.lock() in ctor
        
            for ( const function<T>& listener : listeners ) {
                listener ( forward<TArgs> ( args )... )  ; // perfect forwarding
            }
        } // when lg object is about to die, its dtor is called and
        // inside the dtor it calls m.unlock() - irrespective of 
        // whether exception has occurred or not
        
        // some code
      
    } 
} ;

class ReminderLogic {
    
private:
    
    vector<Reminder> reminders ; 
    
public:

    Event<void(string)> Alarm ;  
    
private:


mutex m ;
    thread monitorThread ;

	

    
    // will be called in secondary thread
    void monitorSystemTime(/* ReminderLogic * const this */ ) { 
        
	lock_guard<mutex> lg ( m ) ; 

        while ( true ) {
            
            // TODO: obtain system time 
            
            // TODO: Compare each reminder with the system time
            for ( const Reminder& reminder : reminders ) { 
                
                // compare with system
                // if reminder is found - display the message
                string message = reminder.getMessage() ; // make copy of message object
                
                Alarm.notify ( message ) ; // ST
               
               // TODO: reminder object will be removed from vector object
                
            }
            
            thread::sleep(60000); // 60 seconds
        }
        
    } // secondary when exits the function, the thread dies
    

public:

    ReminderLogic()  {

monitorThread = bind(&ReminderLogic::monitorSystemTime,this) ;
    }
    
    // main thread
    void addReminder ( int day, int month, int year, int hour, int minute, const string& message ) {

	lock_guard<mutex> m ; 
        // emplace_back always needs ctor with same number of parameters
        reminders.emplace_back ( day, month, year, hour, minute, message ) ;
    }

    
} ;


class InputAbstraction {
    virtual void takeInput ( int& day, int& month, int& year, int& hour, int& minute, string& message ) = 0 ; 
} ;

class InputImplementation1 : public InputAbstraction { 
    void takeInput ( int& day, int& month, int& year, int& hour, int& minute, string& message ) {
        cout << "Enter Day: " ;
        cin >> day ; // main thread
        
        cout << "Enter Month: " ;
        cin >> month ; // main thread
        
        cout << "Enter Year: " ;
        cin >> year ; // main thread
        
        cout << "Enter Hour: " ;
        cin >> hour ; // main thread
        
        cout << "Enter Minute: " ;
        cin >> minute ; // main thread
        
        cout << "Enter  Message: " ;
        cin >> message ; // main thread
    }
}; 

class InputImplementation2 : public InputAbstraction { 
    void takeInput ( int& day, int& month, int& year, int& hour, int& minute, string& message ) {
                
        cout << "Enter Year: " ;
        cin >> year ; // main thread
             
        cout << "Enter Month: " ;
        cin >> month ; // main thread
        
        cout << "Enter Day: " ;
        cin >> day ; // main thread
        
        cout << "Enter Hour: " ;
        cin >> hour ; // main thread
        
        cout << "Enter Minute: " ;
        cin >> minute ; // main thread
        
        cout << "Enter  Message: " ;
        cin >> message ; // main thread
    }
}; 

// simple factory pattern
unique_ptr<InputAbstraction> GetInputImplementation() {
    
    return unique_ptr<InputAbstraction> ( new InputImplementation2() ) ;
    
}

// Presentation Logic Layer - Can contain many classes
// SRP
// Purpose: To take reminders as input from the user and display 
// reminder message to user and reminder is found.
class ConsoleUI {
    
private:

    // Tight Coupling
    ReminderLogic reminderLogic ; // instance data member
    unique_pr<InputAbstraction> inputAbstraction ; // instance data member
    
public:

    ConsoleUI( ) {
        
        inputAbstraction = GetInputImplementation() ;
        
        reminderLogic.Alarm += [] ( string message ) { 
            // TODO: display the message on the screen
        } ;
        
    }

    // this is parameter of every instance method
    void show ( /* ConsoleUI * const this = &cui */ ) { 
        
        int day, month, year, hour, minute ; 
        string message ; 
     
        // main thread
        while ( true ) {
            
           inputAbstraction->takeInput ( day, month, year, hour, minute, message ) ; 
            
            // main thread
            reminderLogic.addReminder ( day, month, year, hour, minute, message ) ; 
            
        }
        
    } // this will be killed here
    
} ;


// Entry Point
// main is called using Main Thread - that is created by operating system
int main() {
    
    // Create UI-class object
    ConsoleUI cui ; // statically allocated object - will get created on Main Thread stack
    cui.show() ; // show ( &cui ) ; // show will be called using main thread
    
    return 0 ;
} // cui will be killed here when main thread exits main()










#include <iostream>
#include <memory>
#include <vector>
#include <string>
using namespace std ; 

class InternalState {
public:
    virtual ~InternalState() { } 
    virtual void undo() = 0 ; 
} ;

class Circle {
private:
    int cx, cy, radius ; // internal state
public:
    int getCX() const { return cx ; }
    int getCY() const { return cy ; }
    int getRadius() const { return cx ; }
    Circle ( int cx, int cy, int radius ) : cx(cx), cy(cy), radius(radius) { 
    }
    
private:

    class Position : public InternalState {
    public:
        Circle *circle ; 
        int cx, cy; 
        Position ( /* Position * const this */ Circle *circle, int cx, int cy ) : circle(circle), cx(cx), cy(cy) { }
        void undo( /* Position * const this */ ) { 
            circle->cx = this->cx ; // call the setter
            circle->cy = this->cy ; // call the setter
        }
    } ;
    
public:
    
    unique_ptr<InternalState> changePosition ( /* Circle * const this */ int cx, int cy ) {
        
        // capturing the internal state of the object
        unique_ptr<InternalState> position ( new Position(this, this->cx, this->cy) ) ;
        
        this->cx = cx ; 
        this->cy = cy ; 
        
        // externalize it
        return position;
        
    }
    
private:
    
    class Size : public InternalState {
    public:
        Circle *circle ; 
        int radius; 
        Size ( Circle *circle, int radius ) : circle(circle), radius(radius) { }
        void undo() { 
            circle->radius = this->radius ;
        }
    } ;
    
public:
    unique_ptr<InternalState> changeSize ( /* Circle const * this */ int radius ) { 
       
        // capturing the internal state of the object
        unique_ptr<InternalState> size ( new Size(this, this->radius) ) ;
        
        this->radius = radius ;
        
        // externalize it
        return size;
        
    }
    void draw()  { 
        cout << "Circle: " << cx << " " << cy << " " << radius << endl ;
    }
} ;

class Guitar { 
private:
    string image ; 
    vector<string> notes ; 
public:
    Guitar ( string image, vector<string>& notes ) : image(image), notes(notes) { 
    }
    void changeImage() {
        this->image = image ; 
    }
    void changeNotes(vector<string>& notes ) {
        this->notes = notes ;
    }
    void draw() {
        cout << "Guitar: " << this->image << endl ;
    }
    void play() {
        for ( string& note : notes ) { 
            cout << note  ;
        }
        cout << endl ; 
    }
} ;


int main() {
    
    stack<unique_ptr<InternalState>> items ; 
    
    Circle c1 ( 10, 10, 100 ) ; 
    Guitar g1 ( "g1.jpg", vector<string> { "A", "B", "C" } ) ; 
    
    c1.draw() ; // Circle: 10, 10, 100
    g1.draw() ; 
    g1.play() ;
    
    items.push ( c1.changePosition(20, 20) ) ;
    c1.draw() ; // Circle: 20, 20, 100
    
    items.push ( c1.changePosition(30, 30) ) ;
    c1.draw() ; // Circle: 30, 30, 100
    
    items.push ( c1.changeSize(300) ) ;
    c1.draw() ; // Circle: 30, 30, 300
    
    unique_ptr<InternalState> item = items.pop(); 
    items->undo();
    c1.draw(); // Circle: 30, 30, 100
    
    unique_ptr<InternalState> item = items.pop(); 
    items->undo();
    c1.draw // Circle: 20, 20, 100
    
    unique_ptr<InternalState> item = items.pop(); 
    items->undo();
    c1.draw() ; // Circle: 10, 10, 100
    
    
    return 0 ;
}










// Example program
#include <iostream>
#include <string>
#include <thread>
#include <queue>
#include <conditional_variable>
#include <mutex>
using namespace std ; 

class Logger {
public:
    virtual void log ( const string& message ) = 0 ;
} ;

class ConsoleLogger : public Logger { 
    void log ( const string& message ) {
        cout << message << endl ; 
    }
} ;

// thread-safe queue class
template<class T>
class concurrent_queue final { 
private:
     queue<T> filepaths ;
     mutex m ; 
public:
    concurrent_queue(const concurrent_queue& ) = delete ; 
    concurrent_queue& ( const concurrent_queue& ) = delete ;
    void push( const T& item ) {
        lock_guard<mutex> lg ( m ) ;
        filepaths.push_back ( item ) ;
    }
    const &T front( ) {
        lock_guard<mutex> lg ( m ) ;
        return queue.front();
    }
    T pop( ) {
        lock_guard<mutex> lg ( m ) ;
        return queue.pop();
    }
} ;

// Business Logic Layer
class Uploader {
private:
    Logger *logger = nullptr ;
    thread secondaryThread ;
    concurrent_queue<string> filepaths ;
    
    // secondary thread
    void performUpload() {
        while ( true ) 
        {
            
            if ( !filepaths.empty() )
            {
                string filepath = filepaths.front() ; 
                
                if ( logger != nullptr )
                    logger->log ( filepath + " upload started" ) ;
                
                this_thread::sleep_for(10s); // simulating upload
                
                if ( logger != nullptr )
                    logger->log ( filepath + " upload completed" ) ;
                
                filepath.pop() ; 
            } else {
                // TODO: make thread wait on event object using conditional_variable
                // wait()
            }
            
        }
    } // secondary thread will get killed
    
public:

    // main thread
    Uploader(Logger *logger) : logger (logger) { 
        secondaryThread = bind ( &Uploader::performUpload, this ) ;
    }
    
    // main thread (<= 50ms) the main thread should go back to event loop
    void upload(/* Uploader * const this = &uploader, */ const string& filepath) {
        filepaths.push_back ( filepath ) ; 
        
        // TODO: Signal the Event object 
        // notify()
    }
};

// Presentation Layer - ConsoleUI, Desktop GUI, Mobile UI, Web UI (client & server)
class ConsoleUI {
private:
    ConsoleLogger cl;
    Uploader uploader ; // tight coupling
public:
    ConsoleUI() : uploader(&cl) {
    }
    
    // main thread 
    void show(/* ConsoleUI * const this = &cui */) {
        string filepath ;  // main thread - stack
        while ( true ) { // main thread
            cin >> filepath ; // main thread 
            uploader.upload ( filepath ) ; // upload ( &uploader, filepath ) ;
        }
    }
} ;

// Stub-Code - Main Thread
// 1. Global Variables are created - Main Thread Stack
// 2. calls main()
// 3. when stub code ends global variables are killed

// main() is called using main thread
int main()
{
    // cui object is statically allocated by the main thread
    // it will be created on main thread stack
    ConsoleUI cui ; // cui - Main Thread' Stack
    cui.show() ; // show ( &cui ) ; 

    return 0 ; 
}








class State { 
    virtual void onClose() = 0 ; 
};

class NewFileState : public State {
    Notepad *notepad ; 
    NewFileState(Notepad *notepad) : notepad(notepad) {
    }
     void onClose() {
        // if there is new text typed
            // show prompt: Save, Dont Save, Cancel
                // if Cancel
                    // close the prompt
                // if Dont Save
                    // close the prompt and notepad window
                // if Save
                    // show save file dialog: Save and Cancel
                        // Is Save
                            // Change To ExistingFileState
                            notepad->changeToExistingFileState() ; 
     }
};

class ExistingFileState : public State {
    void onClose() {
        // if there is new text typed
    }
};

class Notepad : public CFrameWnd {
    
    NewFileState nfs ;
    ExistingFileState efs ;
    
    State *currentState ; 
    
public:

    Notepad(/* this = &notepad object */) : nfs(this) {
        // Create Close Button : Attached Event Handler
        this->currentState = &nfs ; 
    }
    
    void changeToExistingFileState(/* this = &notepad object */) {
        this->currentState = &efs ;
    }
    
    void changeToNewFileState(/* this = &notepad object */) {
        this->currentState = &nfs ;
    }
    
    void onClose(/* this = &notepad object */) {
        this->currentState->onClose();
    }
} ;

int main() {
    Notepad notepad ; 
    notepad.show();
}







// Example program
#include <iostream>
#include <string>
#include <vector>
#include <algorithm>>
using namespace std ; 

class NavyData {
private:
    NavyData() { 
    }
    static unique_ptr<NavyData> navyData ; 
    mutex m ;
public:
    static unique_ptr<NavyData> get() {
        if ( navyData == nullptr ) {
            lock_guard<mutex> guard(m); // m.lock()
            if ( navyData == nullptr ) 
                navyData = unique_ptr<NavyData> ( new NavyData() ) ;
        }
        return navyData ; 
    }
    static unique_ptr<NavyData> createNew() {
        return unique_ptr<NavyData> ( new NayData() ) ;
    }
} ;
unique_ptr<NavyData> NavyData::navyData = nullptr ;

int main()
{
    unique_ptr<NavyData>& p1 = NavyData::get();
    unique_ptr<NavyData>& p2 = NavyData::get();
    
  vector<int> tabs = { 10, 20, 30, 40, 50, 60, 70, 80 } ;
  rotate ( begin(tabs) + 2, begin(tabs) + 4, begin(tabs) + 7 ) ;
  for ( int item : tabs ) 
    cout << item << " " ;
    
    return 0 ;
}










#include <iostream>
#include <vector>
#include <algorithm>
#include <list>
#include <mutex>
#include <memory>
#include <iterator>
using namespace std;
/*
 * range-for to work we required below things
 * 1. one internal class iterator
 * 2. begin
 * 3. end
 * 4. operator !=
 * 5. operator *
 * 6. operator ++
 */
class MyCollection {
private:
    int x = 10;
    int y = 20;
    int z = 30;
public:
    class iterator
    {
    private: 
        int index  ; MyCollection *mc ; 
    public:
        iterator ( int index, MyCollection *mc ) : index ( index ), mc(mc) { } 
        
        bool operator !=(/* this = &bit */ const iterator &eit) {
            return this->index != ( eit.index - 1 ) ; 
        }
        
        int operator *(/* this = &bit */) {
            
            this->index++;
            
            if ( this->index == 1 ) 
                return mc->x ; 
            else if ( this->index == 2 )
                return mc->y ;
            else if ( this->index == 3 )
                return mc->z ; 
                
        }
        
        void operator ++ (/* this = &bit */) {
            this->index++ ;
        }
        
        void operator ++ (/* this = &bit */ int dummy ) {
            this->index++ ;
        }
    };
public:
 
    iterator begin(){
        iterator bit ( 0, this ) ;
    }
    
    iterator end() {
        iterator eit ( 4, nullptr ) ;
    }

};

int main() {
    
  
    MyCollection arr;
 
    for( int item : arr ) { // for(MyCollection:: iterator it = items.begin(); it != items.end(); it++)
        cout << item << " "; // int item = *it;
    }
    
    return 0;
}








\#include <iostream>
#include <vector>
#include <algorithm>
#include <list>
#include <mutex>
#include <memory>
#include <iterator>
using namespace std;

/* Shape VTABLE
&Shape::draw
*/
class Shape {
    // *vptr ; // instance data member
public:
    // Shape (/* this = &object */) { this->vptr = &Shape VTable ; } 
    virtual void draw() = 0 ;
} ;

/* Circle VTable
&Circle::dagghfgfgfgfgfgfgrw
*/
class Circle {
    // vptr ; // instance data member
    // Circle (/* this = &object */) { this->vptr = &Circle VTable ; } 
    virtual void dagghfgfgfgfgfgfgrw(/* this = & of object */) {
        cout << "Circle draw" << endl ;
    }
} ;

int main() {
    
    Circle c ; // vptr = &CircleVTable ; 
    
    Shape *s = (Shape*) &c ; 
    
    s->draw() ; // pointer calling virtual function - Late Binding
    // 5 instructions
    // 1. Get the value of pointer (s) -> address of object
    // 2. Get the value of vtpr -> &VTable 
    // 3. Add offset of draw (+0) + Address of VTable = New Address
    // 4. Get the value from New Address -> Address of the Function
    // 5. Address of Function ( Address of Object )
    
    
    return 0;
}








#include <iostream>
#include <vector>
#include <algorithm>
#include <list>
#include <mutex>
#include <memory>
#include <iterator>
using namespace std;

/* Shape VTABLE
&Shape::draw
*/
class Shape {
    // *vptr ; // instance data member
public:
    // Shape (/* this = &object */) { this->vptr = &Shape VTable ; } 
    virtual void draw() = 0 ;
} ;

/* Circle VTABLE
&Circle::draw
*/
class Circle : public Shape {
    // Circle (/* this = &object */) { this->vptr = &Circle VTable ; } 
    void draw(/* this = & of object */) {
        cout << "Circle draw" << endl ;
    }
} ;

int main() {
    
    Circle c ; // vptr = &CircleVTable ; 
    
    Shape *s = &c ; 
    
    s->draw() ; // pointer calling virtual function - Late Binding
    // 5 instructions
    // 1. Get the value of pointer (s) -> address of object
    // 2. Get the value of vtpr -> &VTable 
    // 3. Add offset of draw (+0) + Address of VTable = New Address
    // 4. Get the value from New Address -> Address of the Function
    // 5. Address of Function ( Address of Object )
    
    
    return 0;
}





#include <iostream>
#include <vector>
#include <algorithm>
#include <list>
#include <mutex>
#include <memory>
#include <iterator>
using namespace std;

class Abstraction {
public:
    // define which can be throw implementation classes
    virtual void work() noexcept = 0 ;
} ;

class Implementation1 { 
    Abstraction *abstraction;
public:
    Implementation1 ( Abstraction *abstraction ) : abstraction(abstraction) {
    }
    
    void f1() {
        abstraction->work();
    }
} ;

class VaryingImplementationA1 : public Abstraction {
    void work() {
        cout << "VaryingImplementationA1 work" << endl ;
    }
};

class VaryingImplementationA2 : public Abstraction {
    void work() {
        cout << "VaryingImplementationA1 work" << endl ;
        throw "something here" ; 
    }
};


int main() {
    VaryingImplementationA1 va1 ; 
    Implementation1 i1 ( &va1 ) ;
    i1.f1();
}








#include <iostream>
#include <vector>
#include <algorithm>
#include <list>
#include <mutex>
#include <memory>
#include <iterator>
using namespace std;

/*
I VTable
&I::Dtor
*/
class I {
    // vptr ;
public:
    virtual ~I() { } 
} ;

/*
I1 VTable
&I1::f1
&I1::f2
*/
class I1 : virtual public I {
public:
    // I1 ( this ) { this->vptr = &I1_Vtable ; } 
    virtual void f1() = 0 ; // offset : 0
    virtual void f2() = 0 ; // offset : 8 
};

/* I2 VTable
&I2::F3
&I2::F4
*/
class I2 : virtual public I {
public:
    // ctor ::::
    virtual void f3() = 0 ; // offset : 0
    virtual void f4() = 0 ; // offset : 8 
} ;

/* A1 Vtable - I1
&A1::f1
&A1::f2
*/
/* A1 Vtable - I2
&A1::f3
&A1::f4
*/
class A1 : public I1, public I2 {
    
    // ctor() { I1vptr = &A1Vtable-I1 ; I2vptr = &A1Vtable-I2 } 
    
    void f2() {
         cout << "A1 - f2" << endl ;
    }
    
    void f1() {
        cout << "A1 - f1" << endl ;
    }
    
     void f4() {
         cout << "A1 - f4" << endl ;
    }
    
    void f3() {
        cout << "A1 - f3" << endl ;
    }
};

void work ( I *v ) { // 1000
    
    I1 *i1 = dynamic_cast<I1*> ( v ); // 1000
    if ( i1 != nullptr ) {
        i1->f1() ;
        i1->f2() ;
    }
    
    I2 *i2 = dynamic_cast<I2*> ( v ); // 1000
    if ( i2 != nullptr ) {
        i2->f3() ;
        i2->f4() ;
    }
    
}

int main() {
    
    A1 a1 ; // address of the object - 1000 // 1000 - I1vptr and 1004 - I2vptr
    work ( &a1 ) ; // 1000
    
    return 0 ;
}

// class Abstraction {
// public:
//     // define which can be throw implementation classes
//     virtual void work() noexcept = 0 ;
// } ;

// class Implementation1 { 
//     Abstraction *abstraction;
// public:
//     Implementation1 ( Abstraction *abstraction ) : abstraction(abstraction) {
//     }
    
//     void f1() {
//         abstraction->work();
//     }
// } ;

// class VaryingImplementationA1 : public Abstraction {
//     void work() {
//         cout << "VaryingImplementationA1 work" << endl ;
//     }
// };

// class VaryingImplementationA2 : public Abstraction {
//     void work() {
//         cout << "VaryingImplementationA1 work" << endl ;
//         throw "something here" ; 
//     }
// };


// int main() {
//     VaryingImplementationA1 va1 ; 
//     Implementation1 i1 ( &va1 ) ;
//     i1.f1();
// }






#include <iostream>
#include <vector>
#include <algorithm>
#include <list>
#include <mutex>
#include <memory>
#include <iterator>
using namespace std;

/*
I VTable
&I::Dtor
*/
class I {
    // vptr ;
public:
    virtual ~I() { } 
} ;

/*
I1 VTable
&I1::f1
&I1::f2
*/
class I1 : virtual public I {
public:
    // I1 ( this ) { this->vptr = &I1_Vtable ; } 
    virtual void f1() = 0 ; // offset : 0
    virtual void f2() = 0 ; // offset : 8 
};

/* I2 VTable
&I2::F3
&I2::F4
*/
class I2 : virtual public I {
public:
    // ctor ::::
    virtual void f3() = 0 ; // offset : 0
    virtual void f4() = 0 ; // offset : 8 
} ;

/* A1 Vtable - I1
&A1::f1
&A1::f2
*/
/* A1 Vtable - I2
&A1::f3
&A1::f4
*/
class A1 : public I1, public I2 {
    
    // ctor() { I1vptr = &A1Vtable-I1 ; I2vptr = &A1Vtable-I2 } 
    
    void f2() {
         cout << "A1 - f2" << endl ;
    }
    
    void f1() {
        cout << "A1 - f1" << endl ;
    }
    
     void f4() {
         cout << "A1 - f4" << endl ;
    }
    
    void f3() {
        cout << "A1 - f3" << endl ;
    }
};

void work ( I *v ) { // 1000
    
    I1 *i1 = dynamic_cast<I1*> ( v ); // 1000
    if ( i1 != nullptr ) {
        i1->f1() ;
        i1->f2() ;
    }
    
    I2 *i2 = dynamic_cast<I2*> ( v ); // 1000
    if ( i2 != nullptr ) {
        i2->f3() ;
        i2->f4() ;
    }
    
}

int main() {
    
    A1 a1 ; // address of the object - 1000 // 1000 - I1vptr and 1004 - I2vptr
    work ( &a1 ) ; // 1000
    
    return 0 ;
}

// class Abstraction {
// public:
//     // define which can be throw implementation classes
//     virtual void work() noexcept = 0 ;
// } ;

// class Implementation1 { 
//     Abstraction *abstraction;
// public:
//     Implementation1 ( Abstraction *abstraction ) : abstraction(abstraction) {
//     }
    
//     void f1() {
//         abstraction->work();
//     }
// } ;

// class VaryingImplementationA1 : public Abstraction {
//     void work() {
//         cout << "VaryingImplementationA1 work" << endl ;
//     }
// };

// class VaryingImplementationA2 : public Abstraction {
//     void work() {
//         cout << "VaryingImplementationA1 work" << endl ;
//         throw "something here" ; 
//     }
// };


// int main() {
//     VaryingImplementationA1 va1 ; 
//     Implementation1 i1 ( &va1 ) ;
//     i1.f1();
// }





#include <iostream>
#include <vector>
#include <algorithm>
#include <list>
#include <mutex>
#include <memory>
#include <iterator>
using namespace std;
/*
 * range-for to work we required below things
 * 1. one internal class iterator
 * 2. begin
 * 3. end
 * 4. operator !=
 * 5. operator *
 * 6. operator ++
 */
class MyCollection {
private:
    int x = 10;
    int y = 20;
    int z = 30;
public:
    class iterator
    {
    private: 
        int index  ; MyCollection *mc ; 
    public:
        iterator ( int index, MyCollection *mc ) : index ( index ), mc(mc) { } 
        
        bool operator != (/* this = &bit */ const iterator &eit ) {
            return this->index != eit.index  ; 
        }
        
        int operator *(/* this = &bit */) {
            
            if ( this->index == 1 ) 
                return mc->x ; 
            else if ( this->index == 2 )
                return mc->y ;
            else if ( this->index == 3 )
                return mc->z ; 
                
        }
        
        void operator ++ (/* this = &bit */) {
            this->index++ ;
        }
        
        void operator ++ (/* this = &bit */ int dummy ) {
            this->index++ ;
        }
    };
public:
 
    iterator begin(){
        iterator bit ( 1, this ) ;
        return bit ;
    }
    
    iterator end() {
        iterator eit ( 4, nullptr ) ;
        return eit ;
    }

};

int main() {
    
  
    MyCollection arr;
 
    for( int item : arr ) { // for(MyCollection:: iterator it = items.begin(); it != items.end(); it++)
        cout << item << " "; // int item = *it;
    }
    
    return 0;
}













