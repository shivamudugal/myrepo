// Example program
#include <iostream>
#include <string>
#include <thread>
#include <queue>
#include <conditional_variable>
#include <mutex>
using namespace std ; 

class Logger {
public:
    virtual void log ( const string& message ) = 0 ;
} ;

class ConsoleLogger : public Logger { 
    void log ( const string& message ) {
        cout << message << endl ; 
    }
} ;

// thread-safe queue class
template<class T>
class concurrent_queue final { 
private:
     queue<T> filepaths ;
     mutex m ; 
public:
    concurrent_queue(const concurrent_queue& ) = delete ; 
    concurrent_queue& ( const concurrent_queue& ) = delete ;
    void push( const T& item ) {
        lock_guard<mutex> lg ( m ) ;
        filepaths.push_back ( item ) ;
    }
    const &T front( ) {
        lock_guard<mutex> lg ( m ) ;
        return queue.front();
    }
    T pop( ) {
        lock_guard<mutex> lg ( m ) ;
        return queue.pop();
    }
} ;

// Business Logic Layer
class Uploader {
private:
    Logger *logger = nullptr ;
    thread secondaryThread ;
    concurrent_queue<string> filepaths ;
    
    // secondary thread
    void performUpload() {
        while ( true ) 
        {
            
            if ( !filepaths.empty() )
            {
                string filepath = filepaths.front() ; 
                
                if ( logger != nullptr )
                    logger->log ( filepath + " upload started" ) ;
                
                this_thread::sleep_for(10s); // simulating upload
                
                if ( logger != nullptr )
                    logger->log ( filepath + " upload completed" ) ;
                
                filepath.pop() ; 
            } else {
                // TODO: make thread wait on event object using conditional_variable
                // wait()
            }
            
        }
    } // secondary thread will get killed
    
public:

    // main thread
    Uploader(Logger *logger) : logger (logger) { 
        secondaryThread = bind ( &Uploader::performUpload, this ) ;
    }
    
    // main thread (<= 50ms) the main thread should go back to event loop
    void upload(/* Uploader * const this = &uploader, */ const string& filepath) {
        filepaths.push_back ( filepath ) ; 
        
        // TODO: Signal the Event object 
        // notify()
    }
};

// Presentation Layer - ConsoleUI, Desktop GUI, Mobile UI, Web UI (client & server)
class ConsoleUI {
private:
    ConsoleLogger cl;
    Uploader uploader ; // tight coupling
public:
    ConsoleUI() : uploader(&cl) {
    }
    
    // main thread 
    void show(/* ConsoleUI * const this = &cui */) {
        string filepath ;  // main thread - stack
        while ( true ) { // main thread
            cin >> filepath ; // main thread 
            uploader.upload ( filepath ) ; // upload ( &uploader, filepath ) ;
        }
    }
} ;

// Stub-Code - Main Thread
// 1. Global Variables are created - Main Thread Stack
// 2. calls main()
// 3. when stub code ends global variables are killed

// main() is called using main thread
int main()
{
    // cui object is statically allocated by the main thread
    // it will be created on main thread stack
    ConsoleUI cui ; // cui - Main Thread' Stack
    cui.show() ; // show ( &cui ) ; 

    return 0 ; 
}