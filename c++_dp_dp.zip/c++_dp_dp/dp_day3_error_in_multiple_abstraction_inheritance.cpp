#include <iostream>
#include <vector>
#include <algorithm>
#include <list>
#include <mutex>
#include <memory>
#include <iterator>
using namespace std;

/*
I1 VTable
&I1::f1
&I1::f2
*/
class I1 {
    // vptr ; 
public:
    // I1 ( this ) { this->vptr = &I1_Vtable ; } 
    virtual void f1() = 0 ; // offset : 0
    virtual void f2() = 0 ; // offset : 8 
};

/* I2 VTable
&I2::F3
&I2::F4
*/
class I2 {
    // vptr ;
public:
    // ctor ::::
    virtual void f3() = 0 ; // offset : 0
    virtual void f4() = 0 ; // offset : 8 
} ;

/* A1 Vtable - I1
&A1::f1
&A1::f2
*/
/* A1 Vtable - I2
&A1::f3
&A1::f4
*/
class A1 : public I1, public I2 {
    
    // ctor() { I1vptr = &A1Vtable-I1 ; I2vptr = &A1Vtable-I2 } 
    
    void f2() {
         cout << "A1 - f2" << endl ;
    }
    
    void f1() {
        cout << "A1 - f1" << endl ;
    }
    
     void f4() {
         cout << "A1 - f4" << endl ;
    }
    
    void f3() {
        cout << "A1 - f3" << endl ;
    }
};

void work ( void *v ) {
    
    I1 *i1 = (I1*) v;
    i1->f1() ;
    i1->f2() ;
    
    I2 *i2 = (I2*) v;
    i2->f3() ;
    i2->f4() ;
}

int main() {
    
    A1 a1 ; // I1vptr and I2vptr
    work ( &a1 ) ; 
    
    return 0 ;
}