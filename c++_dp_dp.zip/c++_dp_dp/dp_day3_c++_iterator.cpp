#include <iostream>
#include <vector>
#include <algorithm>
#include <list>
#include <mutex>
#include <memory>
#include <iterator>
using namespace std;
/*
 * range-for to work we required below things
 * 1. one internal class iterator
 * 2. begin
 * 3. end
 * 4. operator !=
 * 5. operator *
 * 6. operator ++
 */
class MyCollection {
private:
    int x = 10;
    int y = 20;
    int z = 30;
public:
    class iterator
    {
    private: 
        int index  ; MyCollection *mc ; 
    public:
        iterator ( int index, MyCollection *mc ) : index ( index ), mc(mc) { } 
        
        bool operator != (/* this = &bit */ const iterator &eit ) {
            return this->index != eit.index  ; 
        }
        
        int operator *(/* this = &bit */) {
            
            if ( this->index == 1 ) 
                return mc->x ; 
            else if ( this->index == 2 )
                return mc->y ;
            else if ( this->index == 3 )
                return mc->z ; 
                
        }
        
        void operator ++ (/* this = &bit */) {
            this->index++ ;
        }
        
        void operator ++ (/* this = &bit */ int dummy ) {
            this->index++ ;
        }
    };
public:
 
    iterator begin(){
        iterator bit ( 1, this ) ;
        return bit ;
    }
    
    iterator end() {
        iterator eit ( 4, nullptr ) ;
        return eit ;
    }

};

int main() {
    
  
    MyCollection arr;
 
    for( int item : arr ) { // for(MyCollection:: iterator it = items.begin(); it != items.end(); it++)
        cout << item << " "; // int item = *it;
    }
    
    return 0;
}