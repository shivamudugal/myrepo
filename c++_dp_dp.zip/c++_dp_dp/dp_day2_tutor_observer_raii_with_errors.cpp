#include <iostream> // cin, cout, endl
#include <vector> // vector<> class
#include <string> // string class
#include <thread> // thread class
#include <mutex> // mutex<> class
#include <functional> // function<> class
using namespace std ; 

class Reminder { 
private:
    int day, month, year, hour, minute ; 
    string message ;
    
public:

    // making object non-copyable
    Reminder ( const Reminder& ) = delete ; 
    Reminder& operator= ( const Reminder& ) = delete ; 

    // getters
    int getDay ( /* Reminder const * const this */ ) const { return this->day ; } 
    int getMonth ( /* Reminder const * const this */ ) const { return this->month ; }
    int getYear ( /* Reminder const * const this */ ) const { return this->year ; }
    int getHour ( /* Reminder const * const this */ ) const { return this->hour ; }
    int getMinute ( /* Reminder const * const this */ ) const { return this->minute ; }
    const string& getMessage ( /* Reminder const * const this */ ) const { return this->message ; }
    
    Reminder(/* Reminder * const this */) {
    }
    
    Reminder (/* Reminder * const this */ int day, int month, int year, int hour, int minute, const string& message ) 
        : day(day), month(month), year(year), hour(hour), minute(minute), message(message) 
    { 
    }
}

// Rule 1: Break down the application into layers

// Data Access Layer - Can contain many classes


// Business Logic Layer - Can contain many classes

template<class T>
class Event {
private:

    vector<function<T>> listeners ; 
    mutex m ; // this is for synchronization of multiple threads working same object
    
public:

    Event ( const Event& ) = delete ; 
    Event& operator = ( const Event& ) = delete ; 
    
    Event() { }

    // this function might be called in different threads
    operator += (const function<T>& listener) {
        
        lock_guard<mutex> lg ( m ) ; 
        // when lg object is created it calls m.lock() in ctor

        listeners.push_back(listener);
  
    } // when lg object is about to die, its dtor is called and
    // inside the dtor it calls m.unlock() - irrespective of 
    // whether exception has occurred or not
    
    
    // this function might be called in different threads
    operator -= (const function<T>& listener) {
   
         lock_guard<mutex> lg ( m ) ; 
        // when lg object is created it calls m.lock() in ctor
        
        // TODO: remove the listener from the vector

    } // when lg object is about to die, its dtor is called and
    // inside the dtor it calls m.unlock() - irrespective of 
    // whether exception has occurred or not
    
    // this function might be called in secondary thread
    // variadic templates
    template<class TArgs...>
    void notify(TArgs&& args...) {
        
        {
            lock_guard<mutex> lg ( m ) ; 
            // when lg object is created it calls m.lock() in ctor
        
            for ( const function<T>& listener : listeners ) {
                listener ( forward<TArgs> ( args )... )  ; // perfect forwarding
            }
        } // when lg object is about to die, its dtor is called and
        // inside the dtor it calls m.unlock() - irrespective of 
        // whether exception has occurred or not
        
        // some code
      
    } 
} ;

class ReminderLogic {
    
private:
    
    vector<Reminder> reminders ; 
    
public:

    Event<void(string)> Alarm ;  
    
private:

    thread monitorThread ;

    
    // will be called in secondary thread
    void monitorSystemTime(/* ReminderLogic * const this */ ) { 
        
        while ( true ) {
            
            // TODO: obtain system time 
            
            // TODO: Compare each reminder with the system time
            for ( const Reminder& reminder : reminders ) { 
                
                // compare with system
                // if reminder is found - display the message
                string message = reminder.getMessage() ; // make copy of message object
                
                Alarm.notify ( message ) ; // ST
               
               // TODO: reminder object will be removed from vector object
                
            }
            
            thread::sleep(60000); // 60 seconds
        }
        
    } // secondary when exits the function, the thread dies
    

public:

    ReminderLogic() : monitorThread(bind(&ReminderLogic::monitorSystemTime,this)) {
    }
    
    // main thread
    void addReminder ( int day, int month, int year, int hour, int minute, const string& message ) {
        // emplace_back always needs ctor with same number of parameters
        reminders.emplace_back ( day, month, year, hour, minute, message ) ;
    }
    
} ;


// Presentation Logic Layer - Can contain many classes
// SRP
// Purpose: To take reminders as input from the user and display 
// reminder message to user and reminder is found.
class ConsoleUI {
    
private:

    // Tight Coupling
    ReminderLogic reminderLogic ; // instance data member
    
public:

    ConsoleUI( ) {
        reminderLogic.Alarm += [] ( string message ) { 
            // TODO: display the message on the screen
        } ;
    }

    // this is parameter of every instance method
    void show ( /* ConsoleUI * const this = &cui */ ) { 
        
        int day, month, year, hour, minute ; 
        string message ; 
     
        // main thread
        while ( true ) {
            
            cout << "Enter Day: " ;
            cin >> day ; // main thread
            
            cout << "Enter Month: " ;
            cin >> month ; // main thread
            
            cout << "Enter Year: " ;
            cin >> year ; // main thread
            
            cout << "Enter Hour: " ;
            cin >> hour ; // main thread
            
            cout << "Enter Minute: " ;
            cin >> minute ; // main thread
            
            cout << "Enter  Message: " ;
            cin >> message ; // main thread
            
            // main thread
            reminderLogic.addReminder ( day, month, year, hour, minute, message ) ; 
            
        }
        
    } // this will be killed here
    
} ;


// Entry Point
// main is called using Main Thread - that is created by operating system
int main() {
    
    // Create UI-class object
    ConsoleUI cui ; // statically allocated object - will get created on Main Thread stack
    cui.show() ; // show ( &cui ) ; // show will be called using main thread
    
    return 0 ;
} // cui will be killed here when main thread exits main()