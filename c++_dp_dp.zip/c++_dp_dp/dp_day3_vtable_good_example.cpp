#include <iostream>
#include <vector>
#include <algorithm>
#include <list>
#include <mutex>
#include <memory>
#include <iterator>
using namespace std;

/* Shape VTABLE
&Shape::draw
*/
class Shape {
    // *vptr ; // instance data member
public:
    // Shape (/* this = &object */) { this->vptr = &Shape VTable ; } 
    virtual void draw() = 0 ;
} ;

/* Circle VTABLE
&Circle::draw
*/
class Circle : public Shape {
    // Circle (/* this = &object */) { this->vptr = &Circle VTable ; } 
    void draw(/* this = & of object */) {
        cout << "Circle draw" << endl ;
    }
} ;

int main() {
    
    Circle c ; // vptr = &CircleVTable ; 
    
    Shape *s = &c ; 
    
    s->draw() ; // pointer calling virtual function - Late Binding
    // 5 instructions
    // 1. Get the value of pointer (s) -> address of object
    // 2. Get the value of vtpr -> &VTable 
    // 3. Add offset of draw (+0) + Address of VTable = New Address
    // 4. Get the value from New Address -> Address of the Function
    // 5. Address of Function ( Address of Object )
    
    
    return 0;
}